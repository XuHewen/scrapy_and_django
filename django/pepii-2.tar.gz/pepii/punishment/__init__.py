default_app_config = "punishment.apps.PunishmentConfig"
