# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class PunishmentConfig(AppConfig):
    name = 'punishment'
    verbose_name = u'处罚信息管理'
