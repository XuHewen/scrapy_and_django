# -*- coding:utf-8 -*-
from django.apps import AppConfig


class LeadersConfig(AppConfig):
    name = 'leaders'
    verbose_name = u'领导人信息录入'
