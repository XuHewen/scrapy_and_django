### Python
python = 2.7 / 3.6
### django 版本
django = 1.11
## 依赖
mysqlclient
django-crispy-forms
django-import-export
future